setwd("C:/Users/pubud/OneDrive/Desktop/sliit/Y2 S1/PAS/IT24100678_PAS/IT24100678Lab9")
x <- c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)
t.test(x, mu = 3)
x <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)
t.test(x, mu = 25, alternative = "less")
res <- t.test(x, mu = 25, alternative = "less")
res$statistic
res$p.value
res$conf.int
set.seed(123)
x <- rnorm(30, mean = 9.8, sd = 0.05)
t.test(x, mu = 10, alternative = "greater")
set.seed(321)
x <- rnorm(25, mean = 45, sd = 2)
t.test(x, mu = 46, alternative = "less")

